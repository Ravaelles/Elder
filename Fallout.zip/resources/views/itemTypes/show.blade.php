@extends('app')

@section('content')
<div class="container">
	 @include('itemTypes.show_fields')
</div>
@endsection
